package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

public class AbuseReport {

	private int id;
	private int status;
	private int reporterId;
	private String reporterName;
	private String reporterAddress;
	private String reporterTelephone;
	private String mandated;
	private String reporterRelationshipToVictim;
	private int allegedVictimPatientId;
	private String allegedVictimName;
	private String allegedVictimAddress;
	private String allegedVictimTelephone;
	private char allegedVictimSex;
	private int allegedVictimStaffId;
	private String allegedVictimDatebirth;
	private int allegedVictimMaritalStatusId;
	private int allegedAbuserPatientId;
	private int allegedAbuserStaffId;
	private String allegedAbuserName;
	private String allegedAbuserAddress;
	private int allegedAbuserRelationshipId;
	private String allegedAbuserSocialSecurity;
	private String allegedAbuserDatebirth;
	private String allegedAbuserTelephone;
	private String communicationNeed;
	private int clientGuardianId;
	private String clientGuardianName;
	private String clientGuardianAddress;
	private String clientGuardianRelationship;
	private String clientGuardianTelephone;
	private int currentlyServedById;
	private String currentlyServedByComment;
	private String collateralContactsNotification;
	private String typeOfServiceComment;
	private String typeOfAbuseReport;
	private String frequencyOfAbuse;
	private String isVictimAware;
	private String descriptionAllegedReport;
	private String descriptionLevelRisk;
	private String descriptionResultingInjuries;
	private String descriptionWitnesses;
	private String descriptionCaregiverRelationship;
	private String oralReportFilled;
	private String oralReportFilledComment;
	private String riskToInvestigator;
	private String riskToInvestigatorComment;
	private String dateOfLastIncident;
	private String dispositionLetter;
	private String decisionLetter;
	private String appealLetter;
	private Connection conn;
	
	public AbuseReport(int id, String reporterName, int status, Connection conn){
		this.id = id;
		this.reporterName = reporterName;
		this.status = status;
		this.conn =conn;
	}
	
	public int getId(){
		return id;
	}
	
	public String getReporterName(){
		return reporterName;
	}
	
	public int getStatus(){
		return status;
	}
	
	
	public static List<AbuseReport> userAbuseReportView(int userType, int userId, Connection conn){
		List<AbuseReport> listOfAbuseReport = new LinkedList<AbuseReport>();
		if (userType==1||userType==2){
		String sql = "SELECT id, reporter_name, status FROM abuse_report";
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()){
				
			int id = rs.getInt("id");
			String reporterName = rs.getString("reporter_name");
			int status = rs.getInt("status");
			AbuseReport abuseReport = new AbuseReport(id, reporterName, status, conn);
			listOfAbuseReport.add(abuseReport);
			}
			rs.close();
			stmt.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		}
		else if (userType==3){
			String sql ="SELECT id,reporter_name, status FROM abuse_report WHERE reporter_id=?";
			PreparedStatement stmt;
			try {
				stmt = conn.prepareStatement(sql);
				stmt.setInt(1, userId);
				ResultSet rs = stmt.executeQuery();
				while (rs.next()){
					int id = rs.getInt("id");
					String reporterName = rs.getString("reporter_name");
					int status = rs.getInt("status");
					AbuseReport abuseReport = new AbuseReport(id, reporterName, status, conn);
					listOfAbuseReport.add(abuseReport);
				}
				rs.close();
				stmt.close();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return listOfAbuseReport;
	}
}
