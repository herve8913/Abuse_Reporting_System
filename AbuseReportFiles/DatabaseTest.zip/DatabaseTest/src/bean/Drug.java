package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.Date;

public class Drug {
	private Connection conn;
	private int status;
	private String drugName;
	private String descriptionText;
	private String message;
	private String searchResult;

	public Drug(int status, String drugName, String descriptionText,
			Connection conn) {
		this.status = status;
		this.drugName = drugName;
		this.descriptionText = descriptionText;
		this.conn = conn;
	}

	public Drug(String drugName, Connection conn) {
		this.drugName = drugName;
		this.conn = conn;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getDrugName() {
		return drugName;
	}

	public void setDrugName(String drugName) {
		this.drugName = drugName;
	}

	public String getDescriptionText() {
		return descriptionText;
	}

	public void setDescriptionText(String descriptionText) {
		this.descriptionText = descriptionText;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getSearchResult() {
		return searchResult;
	}

	public void setSearchResult(Date date, Time time, int stat, String drug_name, String description) {
		this.searchResult = "Date: " + date + "Time: " + time + "Status: "
				+ stat + "drug_name: " + drug_name + "description"
				+ description;;
	}

	public boolean valid() {

		if (drugName == "") {
			message = "Drug Name cannot be null";
		} else if (descriptionText == "") {
			message = "Description Text cannot be null";
		} else {
			return true;
		}
		setMessage(message);
		return false;
	}

	public boolean exist() {
		int count = 0;
		String sql = "SELECT COUNT(*) AS count FROM drug WHERE drug_name=?";

		PreparedStatement stmt;
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, drugName);

			ResultSet rs = stmt.executeQuery();

			if (rs.next()) {
				count = rs.getInt("count");
			}

			rs.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if (count == 0) {
			setMessage("This drug doesn't exist in the database.");
			return false;
		} else {
			return true;
		}
	}

	public void register() {
		String sql = "INSERT INTO drug (status, drug_name, description) VALUES (?, ?, ?)";

		PreparedStatement stmt;
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, status);
			stmt.setString(2, drugName);
			stmt.setString(3, descriptionText);

			stmt.executeUpdate();

			stmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public boolean search() {
		searchResult = null;
		String sql = "SELECT created, modified, status, drug_name, description FROM drug WHERE drug_name=?";
		PreparedStatement selectStmt;
		try {
			selectStmt = conn.prepareStatement(sql);
			selectStmt.setString(1, drugName);

			ResultSet rs = selectStmt.executeQuery();
			if (!rs.next()) {
				searchResult = "This drug with name: " + drugName
						+ " doesn't exist.";
				return false;
			}
			do {
				Date date = rs.getDate("created");
				Time time = rs.getTime("modified");
				int stat = rs.getInt("status");
				String drug_name = rs.getString("drug_name");
				String description = rs.getString("description");
				setSearchResult(date, time, stat, drug_name, description);
			} while (rs.next());
			rs.close();
			selectStmt.close();
		} catch (SQLException e) {
			System.out.println("sql");
		}

		return true;
	}
	
	public void update(){
		
		String sql="UPDATE drug SET drug_name=?, description=?,status=? WHERE drug_name=?";
		PreparedStatement updateStmt;
		try {
			updateStmt = conn.prepareStatement(sql);
			updateStmt.setString(1,	drugName);
			updateStmt.setString(2, descriptionText);
			updateStmt.setInt(3, status);
			updateStmt.setString(4, drugName);
			updateStmt.executeUpdate();
			updateStmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
