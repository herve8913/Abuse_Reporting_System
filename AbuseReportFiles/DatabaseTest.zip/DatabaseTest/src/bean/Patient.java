package bean;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

public class Patient {

	private int id;
	private int status;
	private String patientName;
	private String patientMidname;
	private String patientLastName;
	private int iq;
	private String birthdate;
	private String sex;
	private String telephone;
	private int maritalStatusId;
	private int groupHomeId;
	private int currentlyServedById;
	private Connection conn;

	public Patient(int id, int status, String patientName, String patientMidname,
			String patientLastName, int iq, String birthdate, String sex,
			String telephone, int maritalStatusId, int groupHomeId,
			int currentlyServedById, Connection conn) {
		this.status = status;
		this.patientName = patientName;
		this.patientMidname = patientMidname;
		this.patientLastName = patientLastName;
		this.iq = iq;
		this.birthdate = birthdate;
		this.sex = sex;
		this.telephone = telephone;
		this.maritalStatusId = maritalStatusId;
		this.groupHomeId = groupHomeId;
		this.currentlyServedById = currentlyServedById;
		this.conn = conn;
	}
	
	public Patient(int id, Connection conn){
		this.id=id;
		this.conn=conn;
	}
	
	public int getId(){
		return id;
	}

	public String getPatientName() {
		return patientName;
	}

	public String getPatientMidname() {
		return patientMidname;
	}

	public String getPatientLastName() {
		return patientLastName;
	}
	

	public String getBirthdate() {
		return birthdate;
	}

	public void setBirthdate(String birthdate) {
		this.birthdate = birthdate;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public int getMaritalStatusId() {
		return maritalStatusId;
	}

	public void setMaritalStatusId(int maritalStatusId) {
		this.maritalStatusId = maritalStatusId;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public static List<Patient> getAllPatient(Connection conn) {
		List<Patient> listOfAllPatient = new LinkedList<Patient>();

		String sql = "SELECT * FROM patient";
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {
				int id = rs.getInt("id");
				int status = rs.getInt("status");
				String patientName = rs.getString("patient_name");
				String patientMidname = rs.getString("patient_midname");
				String patientLastName = rs.getString("patient_last_name");
				int iq = rs.getInt("iq");
				String birthdate = rs.getString("birthdate");
				String sex = rs.getString("sex");
				String telephone = rs.getString("telephone");
				int maritalStatusId = rs.getInt("marital_status_id");
				int groupHomeId = rs.getInt("group_home_id");
				int currentlyServedById = rs.getInt("currently_served_by_id");

				Patient patient = new Patient(id, status, patientName,
						patientMidname, patientLastName, iq, birthdate, sex,
						telephone, maritalStatusId, groupHomeId, currentlyServedById, conn);
				
				listOfAllPatient.add(patient);
				
			}
			
			rs.close();
			stmt.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return listOfAllPatient;
	}

	public void setPatientInfo(){
		String sql = "SELECT * FROM patient WHERE id = ?";
		try {
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setInt(1, id);
			ResultSet rs = stmt.executeQuery();
			if(rs.next()){
				setPatientName(rs.getString("patient_name"));
				setSex(rs.getString("sex"));
				setTelephone(rs.getString("telephone"));
				setBirthdate(rs.getString("birthdate"));
				setMaritalStatusId(rs.getInt("marital_status_id"));
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
