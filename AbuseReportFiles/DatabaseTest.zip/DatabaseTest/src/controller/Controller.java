package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import bean.AbuseReport;
import bean.CommunicationNeed;
import bean.Drug;
import bean.FrequencyOfAbuse;
import bean.Patient;
import bean.Relationship;
import bean.TypeOfAbuse;
import bean.TypeOfService;
import bean.User;

/**
 * Servlet implementation class Controller
 */
@WebServlet("/Controller")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private DataSource ds;
	private HttpSession session;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Controller() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		try {
			InitialContext initContext = new InitialContext();

			ds = (DataSource) initContext
					.lookup("java:/comp/env/jdbc/abusereport");

			System.out.println("datasource");
		} catch (NamingException e) {
			System.out.println("ds");
			throw new ServletException();
		}
		if (ds == null) {
			System.out.println("dsnull");
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String action = request.getParameter("action");

		if (action == null) {
			request.setAttribute("message", "");
			request.getRequestDispatcher("/index.jsp").forward(request,
					response);

		} else if (action.equals("login")) {
			request.setAttribute("email", "");
			request.setAttribute("password", "");
			request.setAttribute("message", "");
			request.getRequestDispatcher("/pages/login.jsp").forward(request,
					response);

		} else if (action.equals("createaccount")) {
			request.setAttribute("email", "");
			request.setAttribute("password", "");
			request.setAttribute("repeatpassword", "");
			request.setAttribute("message", "");
			request.getRequestDispatcher("/pages/createaccount.jsp").forward(
					request, response);

		} else if (action.equals("registerdrug")) {
			request.setAttribute("drugName", "");
			request.setAttribute("descriptionText", "");
			request.setAttribute("status", "1");
			request.setAttribute("message", "");
			request.getRequestDispatcher("/pages/registerdrug.jsp").forward(
					request, response);
		} else if (action.equals("searchdrug")) {
			request.setAttribute("drugName", "");
			request.setAttribute("message", "");
			request.getRequestDispatcher("/pages/searchdrug.jsp").forward(
					request, response);
		} else if (action.equals("updatedrug")) {
			request.setAttribute("drugName", "");
			request.setAttribute("descriptionText", "");
			request.setAttribute("status", "1");
			request.setAttribute("message", "");
			request.getRequestDispatcher("/pages/updatedrug.jsp").forward(
					request, response);
		} else if (action.equals("createreport")) {
			Connection conn;
			try {
				conn = ds.getConnection();
				List<User> listStaffMembers = User.getStaffMembers(conn);
				request.setAttribute("listStaffMembers", listStaffMembers);
				int id = (Integer)session.getAttribute("userId");
				User user = new User(id,conn);
				user.setUserInfo();
				request.setAttribute("userInfo", user);
				List<Patient> listOfAllPatient = Patient.getAllPatient(conn);
				request.setAttribute("listOfAllPatient", listOfAllPatient);
				List<Relationship> listOfRelationship = Relationship.getRelationshipList(conn);
				request.setAttribute("listOfRelationship", listOfRelationship);
				List<TypeOfService> listOfService = TypeOfService.getListOfService(conn);
				request.setAttribute("listOfService", listOfService);
				List<FrequencyOfAbuse> listOfFrequency = FrequencyOfAbuse.getFrequencyOfAbuse(conn);
				request.setAttribute("listOfFrequency", listOfFrequency);
				List<TypeOfAbuse> listOfAbuseType = TypeOfAbuse.getAbuseTypeList(conn);
				request.setAttribute("listOfAbuseType", listOfAbuseType);
				List<CommunicationNeed> listOfComNeed = CommunicationNeed.getListOfComNeed(conn);
				request.setAttribute("listOfComNeed", listOfComNeed);
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			request.getRequestDispatcher("/CreateAbuseReportCreatePage.jsp")
					.forward(request, response);

		} else if(action.equals("logout")) {
			request.setAttribute("message", "");
			request.getRequestDispatcher("/index.jsp").forward(request, response);
			
		}else {
			out.println("unrecognized1");
			return;
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		String action = request.getParameter("action");
		if (action == null) {

			out.println("unrecognized");
			return;
		}
		Connection conn = null;

		try {
			conn = ds.getConnection();
			System.out.println("connected");
		} catch (SQLException e) {
			System.out.println("connection problem");
		}

		if (action.equals("dologin")) {
			String email = request.getParameter("email");
			String password = request.getParameter("password");
			session = request.getSession();
			session.setAttribute("email", email);

			request.setAttribute("email", email);
			request.setAttribute("password", "");

			User user = new User(email, password, conn);

			try {
				List<String> list = user.login1();
				if (list.size()!=0) {
					request.setAttribute("email", email);
					session.setAttribute("userName", list.get(0));
					int userId = Integer.parseInt(list.get(5));
					session.setAttribute("userId",userId);
					int userType = Integer.parseInt(list.get(6));
					session.setAttribute("userType", userType);
					List<AbuseReport> listOfAbuseReport = AbuseReport.userAbuseReportView(userType, userId, conn);
					System.out.println(listOfAbuseReport.size());
					session.setAttribute("userAbuseReportView", listOfAbuseReport);
					request.getRequestDispatcher(
							"/CreateAbuseReportViewPage.jsp").forward(request,
							response);
				} else {
					request.setAttribute("message", " The username or password is invalid. Please check them. ");
					request.getRequestDispatcher("/index.jsp").forward(request,
							response);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if (action.equals("createaccount")) {
			String email = request.getParameter("email");
			String password = request.getParameter("password");
			String repeatpassword = request.getParameter("repeatpassword");

			request.setAttribute("email", email);
			request.setAttribute("password", "");
			request.setAttribute("repeatpassword", "");
			request.setAttribute("message", "");

			if (!password.equals(repeatpassword)) {
				request.setAttribute("message", "check your passowrd");
				request.getRequestDispatcher("/pages/createaccount.jsp")
						.forward(request, response);
			} else {
				User user = new User(email, password, conn);

				if (!user.validate()) {
					// Password or email address has wrong format.
					request.setAttribute("message", user.getMessage());
					request.getRequestDispatcher("/pages/createaccount.jsp")
							.forward(request, response);
				} else {
					try {
						if (user.exists()) {
							// This email address already exists in the user
							// database.
							request.setAttribute("message",
									"An account with this email address already exists");
							request.getRequestDispatcher(
									"/pages/createaccount.jsp").forward(
									request, response);
						} else {
							// We create create the account.
							user.create();
							request.getRequestDispatcher(
									"/pages/createsuccess.jsp").forward(
									request, response);
						}
					} catch (SQLException e) {

						request.getRequestDispatcher("/pages/error.jsp")
								.forward(request, response);
					}
				}

			}
		} else if (action.equals("doregisterdrug")) {

			String drugName = request.getParameter("drugName");
			String descriptionText = request.getParameter("descriptionText");
			String sta = request.getParameter("status");
			int status = Integer.parseInt(sta);

			Drug drug = new Drug(status, drugName, descriptionText, conn);

			if (!drug.valid()) {
				request.setAttribute("message", drug.getMessage());
				request.getRequestDispatcher("/pages/registerdrug.jsp")
						.forward(request, response);
			} else {
				if (drug.exist()) {
					// already exist
					request.setAttribute("message",
							"This drug has already been registered");
					request.getRequestDispatcher("/pages/registerdrug.jsp")
							.forward(request, response);
				} else {
					// register the drug
					drug.register();
					request.setAttribute("drugName", drugName);
					request.getRequestDispatcher("/pages/registersuccess.jsp")
							.forward(request, response);
				}

			}

		} else if (action.equals("dosearch")) {
			String drugName = request.getParameter("drugName");
			request.setAttribute("drugName", drugName);
			Drug drug = new Drug(drugName, conn);
			if (!drug.search()) {
				request.setAttribute("message", drug.getSearchResult());
				request.getRequestDispatcher("/pages/searchdrug.jsp").forward(
						request, response);
			} else {
				request.setAttribute("message", drug.getSearchResult());
				request.getRequestDispatcher("/pages/searchsuccess.jsp")
						.forward(request, response);
			}

		} else if (action.equals("doupdatedrug")) {

			String drugName = request.getParameter("drugName");
			String descriptionText = request.getParameter("descriptionText");
			String sta = request.getParameter("status");
			request.setAttribute("drugName", drugName);
			request.setAttribute("descriptionText", descriptionText);
			request.setAttribute("status", sta);
			int status = Integer.parseInt(sta);

			Drug drug = new Drug(status, drugName, descriptionText, conn);
			if (!drug.valid()) {
				request.setAttribute("message", drug.getMessage());
				request.getRequestDispatcher("/pages/updatedrug.jsp").forward(
						request, response);
			} else {
				if (!drug.exist()) {
					request.setAttribute("message", drug.getMessage());
					request.getRequestDispatcher("/pages/updatedrug.jsp")
							.forward(request, response);
				} else {
					drug.update();
					request.getRequestDispatcher("/pages/updatesuccess.jsp")
							.forward(request, response);
				}
			}
		} else if (action.equals("dosendemail")) {
			String email = request.getParameter("email");
			User user = new User(email, conn);
			if (!user.sendEmail()) {
				request.setAttribute("message", user.getMessage());
				request.getRequestDispatcher("/index.jsp").forward(request,
						response);

			} else {
				request.setAttribute("message", user.getMessage());
				request.getRequestDispatcher("/index.jsp").forward(request,
						response);
			}
		} else if (action.equals("docreatereport")) {
			
			if (request.getParameter("submit")!=null){
				System.out.println("submit");
				int id = (Integer)session.getAttribute("userId");
				User user = new User(id,conn);
				user.setUserInfo();
				String mandated = request.getParameter("mandated");
				String reporterRelationToVictim = request.getParameter("relationship");
				
				
				if(request.getParameter("radio1").equals("Patient")){
					System.out.println("patient");
				int allegedVictimPatientId = Integer.parseInt(request.getParameter("allegedVictimPatient"));
				Patient victim = new Patient(allegedVictimPatientId,conn);
				victim.setPatientInfo();
				}else{
					System.out.println("staff");
					int allegedVictimStaffId = Integer.parseInt(request.getParameter("allegedVictimStaff"));
					User victim = new User(allegedVictimStaffId,conn);
					victim.setUserInfo();
				}
				if(request.getParameter("radio2").equals("Staff")){
					System.out.println("Abuser Staff");
				int abuserStaffId = Integer.parseInt(request.getParameter("allegedAbuserStaff"));
				User abuser = new User(abuserStaffId,conn);
				abuser.setUserInfo();
				}else{
					int abuserPatientId = Integer.parseInt(request.getParameter("allegedAbuserPatient"));
					Patient abuser = new Patient(abuserPatientId,conn);
					abuser.setPatientInfo();
				}
				
				String abuserRelationship = request.getParameter("relationship2");
				String collateralContacts = request.getParameter("collateralcontacts");
				String typeOfService = request.getParameter("typeofservice");
				String[] typeOfAbuse = request.getParameterValues("typesofabuse");
				String[] communicationNeeds = request.getParameterValues("communicationneeds");
				
				
			}
			if(request.getParameter("save")!=null){
				System.out.println("save");
			}
			/*
			String mandated1 = request.getParameter("radios");
			int mandated = Integer.parseInt(mandated1);
			String collateralContactsNotification = request
					.getParameter("collateralcontacts");
			String typeOfServiceId1 = request.getParameter("typeofservice");
			int typeOfServiceId = Integer.parseInt(typeOfServiceId1);
			String dateOfLastIncident = request
					.getParameter("dataoflastincident");*/
		} else {
			out.println("unrecognised action");
		}

		try {
			conn.close();
		} catch (SQLException e) {
			throw new ServletException();
		}

	}

}
